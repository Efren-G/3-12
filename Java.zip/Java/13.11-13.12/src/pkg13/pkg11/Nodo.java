
package pkg13.pkg11;

public class Nodo {

    int dato;
    Nodo der;
    Nodo izq;
    Nodo(int dat)
    {
        this.dato=dat;
        this.der=null;
        this.izq=null;
    }
}
