
package arbolbinario;
public class ArbolBinario {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        arbol1 al= new arbol1(23);
        Nodo nuevo = new Nodo(14);
        al.agregar(nuevo,al.getRaiz());
        al.rcorrerPreorden(al.getRaiz());
    }
    
}
